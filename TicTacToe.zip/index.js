var reset = document.getElementById("reset")
var table = document.getElementById("table")
var row1 = document.getElementById("row1").childNodes
var row2 = document.getElementById("row2").childNodes
var row3 = document.getElementById("row3").childNodes
var char = "X"
var cnum = 0
var rows = [
    [" ", " ", " "],
    [" ", " ", " "],
    [" ", " ", " "]
];
reset.onclick = function reset() {
    row1.forEach(list => {
        list.innerHTML = ""
    })
    row2.forEach(list => {
        list.innerHTML = ""
    })
    row3.forEach(list => {
        list.innerHTML = ""
    })
    c = 0
}
function change() {
    var cpro = cnum % 2
    cnum++
    if (cpro == 0) {
        char = "X"
    } else if (cpro != 0) {
        char = "O"
    }
}
row1.forEach(list => {
    list.onclick = function () {
        if (list.innerHTML == ! " ") {
            change()
            list.innerHTML = char
            rows[0][0] = char
            console.log(rows);
            console.log(list);
        }
    }
});
row2.forEach(list => {
    list.onclick = function () {
        if (list.innerHTML == ! " ") {
            change()
            list.innerHTML = char
        }
    }
});
row3.forEach(list => {
    list.onclick = function () {
        if (list.innerHTML == ! " ") {
            change()
            list.innerHTML = char
        }
    }
});